package com.example.seven;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MainActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    private ImageView imageview;
    private Button btn;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageview = (ImageView) findViewById(R.id.imageview);
        btn = (Button) findViewById(R.id.button1);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                try {
                    Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(i, 1);  //因为要得到照片  因此需要有返回的数据
                } catch (Exception e) {
                    Log.d("cameraDemo", e.toString());
                }
            }
        });
    }
    protected void onActivityResult(int requestcode, int resultCode, Intent data) {   //这里data就是返回的数据
        try {
            if (requestcode != 1) {
                return;
            }
            super.onActivityResult(requestcode, resultCode, data);
            Bundle extras = data.getExtras();
            Bitmap bitmap = (Bitmap) extras.get("data");      //得到data中的data包含的值并赋值给bitmap
            imageview.setImageBitmap(bitmap);
        } catch (Exception e) {
            Log.d("cameraDemo", e.toString());
        }
    }
}
//在启动摄像头程序时，因为要传回拍摄的图像，所以调用了 Activity.startActivityForResult(Intent intent, int requestCode) 方法。
//当 startActivityForResult() 方法启动的 Activity 正常结束时
// 会自动返回发出请求的 Activity，并且该方法会返回对应的 requestCode 值
// 给 onActivityResult(int requestcode, int resultCode,Intent data) 方法
// 借此可以在请求 Activity 和发出请求的 Activity 之间进行数据传递
// 本实例借助于这一特点传回了 Android 系统照相机程序拍摄的照片